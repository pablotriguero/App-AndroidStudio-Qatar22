package com.dam.evaluaciont1_ptp.fragmentos;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dam.evaluaciont1_ptp.R;
import com.dam.evaluaciont1_ptp.javabeans.Partido;

public class ResultadoFragment extends Fragment {

    private static final String ARG_NOMBRE = "NOMBRE";
    private String nombre;

    TextView  tv_Fase;
    TextView  tv_FechaHora;
    TextView  tv_Equipo1;
    TextView  tv_GolesEquipo1;
    TextView  tv_Equipo2;
    TextView  tv_GolesEquipo2;


    //public void Partido;
    public ResultadoFragment(Partido partido) {
        tv_Fase.setText(partido.getTv_Fase());
        tv_FechaHora.setText(partido.getTv_Fecha());
        tv_Equipo1.setText(partido.getTv_Equipo1());
        tv_Equipo2.setText(partido.getTv_Equipo2());
        tv_GolesEquipo1.setText(partido.getTv_Goles_Equipo1());
        tv_GolesEquipo2.setText(partido.getTv_Goles_Equipo2());
    }

    public ResultadoFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_resultado, container, false);

        tv_Fase = view.findViewById(R.id.tv_Fase);
        tv_FechaHora = view.findViewById(R.id.tv_FechaHora);
        tv_Equipo1 = view.findViewById(R.id.tv_Equipo1);
        tv_GolesEquipo1 = view.findViewById(R.id.tv_GolesEquipo1);
        tv_Equipo2 = view.findViewById(R.id.tv_Equipo2);
        tv_GolesEquipo2 = view.findViewById(R.id.tv_GolesEquipo2);



        return view;
    }
}