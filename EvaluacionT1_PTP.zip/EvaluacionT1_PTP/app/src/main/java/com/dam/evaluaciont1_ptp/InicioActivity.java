package com.dam.evaluaciont1_ptp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class InicioActivity extends AppCompatActivity {

    Button btnCoNsultar;
    Button btnRegistrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
       /* //Cambiar color barra titulo
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable
                (new ColorDrawable(getResources().getColor(R.color.topBarRed)));
        //Cambiar nombre barra titulo
        getSupportActionBar().setTitle("Qatar22");*/

        btnCoNsultar = findViewById(R.id.btnConsultar);
        btnRegistrar = findViewById(R.id.btnRegistrar);

        btnCoNsultar.setOnClickListener(c -> consultar());
        btnRegistrar.setOnClickListener(r -> registrar());
    }

    private void registrar() {
        Intent i = new Intent(this, RegistrarResultadoActivity.class);
        //Intent i = new Intent(this, SeleccionActivity.class);
        startActivity(i);
    }

    private void consultar() {
        Intent i = new Intent(this, ConsultaActivity.class);
        startActivity(i);
    }
}