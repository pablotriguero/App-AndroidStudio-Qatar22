package com.dam.evaluaciont1_ptp.datos;

import com.dam.evaluaciont1_ptp.javabeans.Partido;

import java.util.ArrayList;

public class Resultado {
    ArrayList<Partido> listadoResultados = new ArrayList<Partido>();
    public ArrayList<Partido> getListadoResultados() {
        setlistadoResultados();
        return listadoResultados;
    }
    private void setlistadoResultados() {
        this.listadoResultados.clear();
        Partido partido1 = new Partido("Fase de grupos", "20/11/2022 17:00", "Qatar", 0, "Ecuador", 2);
        Partido partido2 = new Partido("Fase de grupos", "21/11/2022 14:00", "Inglaterra", 6, "Irán", 2);
        Partido partido3 = new Partido("Fase de grupos", "21/11/2022 17:00", "Senegal", 0, "Holanda", 2);
        Partido partido4 = new Partido("Fase de grupos", "21/11/2022 20:00", "Estados Unidos", 1, "Gales", 1);
        Partido partido5 = new Partido("Fase de grupos", "22/11/2022 11:00", "Argentina", 1, "Arabia Saudí", 2);
        Partido partido6 = new Partido("Fase de grupos", "22/11/2022 14:00", "Dinamarca", 0, "Túnez", 0);
        Partido partido7 = new Partido("Fase de grupos", "22/11/2022 17:00", "México", 0, "Polonia", 0);
        Partido partido8 = new Partido("Fase de grupos", "22/11/2022 20:00", "Francia", 4, "Australia", 1);
        Partido partido9 = new Partido("Fase de grupos", "23/11/2022 11:00", "Marruecos", 0, "Croacia", 0);
        Partido partido10 = new Partido("Fase de grupos", "23/11/2022 14:00", "Alemania", 1, "Japón", 2);
        Partido partido11 = new Partido("Fase de grupos", "23/11/2022 17:00", "España", 7, "Costa Rica", 0);
        Partido partido12 = new Partido("Fase de grupos", "23/11/2022 20:00", "Belgica", 1, "Canada", 0);
        Partido partido13 = new Partido("Fase de grupos", "24/11/2022 11:00", "Suiza", 1, "Camerun", 0);
        Partido partido14 = new Partido("Fase de grupos", "24/11/2022 14:00", "Uruguay", 0, "Corea del Sur", 0);
        Partido partido15 = new Partido("Fase de grupos", "24/11/2022 17:00", "Portugal", 3, "Ghana", 2);
        Partido partido16 = new Partido("Fase de grupos", "24/11/2022 20:00", "Brasil", 2, "Serbia", 0);
        Partido partido17 = new Partido("Fase de grupos", "25/11/2022 11:00", "Gales", 0, "Irán", 2);
        Partido partido18 = new Partido("Fase de grupos", "25/11/2022 14:00", "Qatar", 1, "Senegal", 3);
        Partido partido19 = new Partido("Fase de grupos", "25/11/2022 17:00", "Holanda", 1, "Ecuador", 1);
        Partido partido20 = new Partido("Fase de grupos", "25/11/2022 20:00", "Inglaterra", 0, "Estados Unidos", 0);
        Partido partido21 = new Partido("Fase de grupos", "26/11/2022 11:00", "Túnez", 0, "Australia", 1);
        Partido partido22 = new Partido("Fase de grupos", "26/11/2022 14:00", "Polonia", 2, "Arabia Saudí", 0);
        Partido partido23 = new Partido("Fase de grupos", "26/11/2022 17:00", "Francia", 2, "Dinamarca", 1);
        Partido partido24 = new Partido("Fase de grupos", "26/11/2022 20:00", "Argentina", 2, "México", 0);
        Partido partido25 = new Partido("Fase de grupos", "27/11/2022 11:00", "Japón", 0, "Costa Rica", 1);
        Partido partido26 = new Partido("Fase de grupos", "27/11/2022 14:00", "Belgica", 0, "Marruecos", 2);
        Partido partido27 = new Partido("Fase de grupos", "27/11/2022 17:00", "Croacia", 4, "Canada", 1);
        Partido partido28 = new Partido("Fase de grupos", "27/11/2022 20:00", "España", 1, "Alemania", 1);
        Partido partido29 = new Partido("Fase de grupos", "28/11/2022 11:00", "Camerun", 3, "Serbia", 3);
        Partido partido30 = new Partido("Fase de grupos", "28/11/2022 14:00", "Corea del Sur", 2, "Ghana", 3);
        Partido partido31 = new Partido("Fase de grupos", "28/11/2022 17:00", "Brasil", 1, "Suiza", 0);
        Partido partido32 = new Partido("Fase de grupos", "28/11/2022 20:00", "Portugal", 2, "Uruguay", 0);

        listadoResultados.add(partido1);
        listadoResultados.add(partido2);
        listadoResultados.add(partido3);
        listadoResultados.add(partido4);
        listadoResultados.add(partido5);
        listadoResultados.add(partido6);
        listadoResultados.add(partido7);
        listadoResultados.add(partido8);
        listadoResultados.add(partido9);
        listadoResultados.add(partido10);
        listadoResultados.add(partido11);
        listadoResultados.add(partido12);
        listadoResultados.add(partido13);
        listadoResultados.add(partido14);
        listadoResultados.add(partido15);
        listadoResultados.add(partido16);
        listadoResultados.add(partido17);
        listadoResultados.add(partido18);
        listadoResultados.add(partido19);
        listadoResultados.add(partido20);
        listadoResultados.add(partido21);
        listadoResultados.add(partido22);
        listadoResultados.add(partido23);
        listadoResultados.add(partido24);
        listadoResultados.add(partido25);
        listadoResultados.add(partido26);
        listadoResultados.add(partido27);
        listadoResultados.add(partido28);
        listadoResultados.add(partido29);
        listadoResultados.add(partido30);
        listadoResultados.add(partido31);
        listadoResultados.add(partido32);
    }
}
