package com.dam.evaluaciont1_ptp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrarResultadoActivity extends AppCompatActivity {

    private static final int LAUNCH_SECOND_ACTIVITY = 1;
    Button btn_seleccionar;
    Button btn_seleccionar2;
    Button btn_guardar_resultado;
    Button btn_limpiar_datos;
    EditText et_fecha_hora;
    EditText et_IntroducirFase;
    EditText Equipo1;
    EditText Equipo2;
    EditText et_gol_Eq_1;
    EditText et_gol_Eq_2;

    String Equipo_1;
    String Equipo_2;

    public static boolean EQUIPO1 = false;
    public static boolean EQUIPO2 = false;

    ActivityResultLauncher<Intent> resultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    System.out.println("Resultado: " + result.getResultCode());
                    if (result.getResultCode() == SeleccionActivity.RESULTADO_EQUIPO1) {
                        Equipo_1 = result.getData().getStringExtra(SeleccionActivity.C_EQUIPO1);
                        Equipo1.setText(Equipo_1);
                    } else if (result.getResultCode() == SeleccionActivity.RESULTADO_EQUIPO2) {
                        Equipo_2 = result.getData().getStringExtra(SeleccionActivity.C_EQUIPO2);
                        Equipo2.setText(Equipo_2);
                    }
                    EQUIPO1 = false;
                    EQUIPO2 = false;

                    if (Equipo_1 != null && Equipo_2 != null) {
                        Equipo1.setText(Equipo_1);
                        Equipo2.setText(Equipo_2);
                    }
                }
            }
    );

    private void irVentana(Class ventana) {
        Intent i = new Intent(this, ventana);
        resultLauncher.launch(i);
        i.getStringExtra(SeleccionActivity.C_EQUIPO1);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_resultado);

        btn_seleccionar = findViewById(R.id.btn_seleccionar);
        btn_seleccionar2 = findViewById(R.id.btn_seleccionar2);
        btn_guardar_resultado = findViewById(R.id.btn_guardar_resultado);
        btn_limpiar_datos = findViewById(R.id.btn_limpiar_datos);
        et_fecha_hora = findViewById(R.id.et_fecha_hora);
        et_IntroducirFase = findViewById(R.id.et_IntroducirFase);
        Equipo1 = findViewById(R.id.Equipo1);
        Equipo2 = findViewById(R.id.Equipo2);
        et_gol_Eq_1 = findViewById(R.id.et_gol_Eq_1);
        et_gol_Eq_2 = findViewById(R.id.et_gol_Eq_2);

        //Para no poder escribir, que solo funcione con el seleccionar
        Equipo1.setEnabled(false);
        Equipo2.setEnabled(false);



        btn_seleccionar.setOnClickListener(v -> {
            EQUIPO1 = true;
            irVentana(SeleccionActivity.class);
        });

        Equipo_1 = getIntent().getStringExtra(SeleccionActivity.C_EQUIPO1);
        Equipo1.setText(Equipo_1);

        btn_seleccionar2.setOnClickListener(v -> {
            EQUIPO2 = true;
            irVentana(SeleccionActivity.class);
        });

        Equipo_2 = getIntent().getStringExtra(SeleccionActivity.C_EQUIPO2);
        Equipo2.setText(Equipo_2);



        btn_guardar_resultado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (et_fecha_hora.getText().toString().isEmpty() ||
                        et_IntroducirFase.getText().toString().isEmpty() ||
                        Equipo1.getText().toString().isEmpty() ||
                        Equipo2.getText().toString().isEmpty() ||
                        et_gol_Eq_1.getText().toString().isEmpty() ||
                        et_gol_Eq_2.getText().toString().isEmpty())
                {
                    Toast.makeText(RegistrarResultadoActivity.this, R.string.No_Guardar, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(RegistrarResultadoActivity.this, R.string.Si_Guardar, Toast.LENGTH_SHORT).show();
                    et_fecha_hora.getText().clear();
                    et_IntroducirFase.getText().clear();
                    Equipo1.getText().clear();
                    Equipo2.getText().clear();
                    et_gol_Eq_1.getText().clear();
                    et_gol_Eq_2.getText().clear();
                }
            }
        });

        btn_limpiar_datos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et_fecha_hora.getText().clear();
                et_IntroducirFase.getText().clear();
                Equipo1.getText().clear();
                Equipo2.getText().clear();
                et_gol_Eq_1.getText().clear();
                et_gol_Eq_2.getText().clear();
                //finish();
            }
        });

    }



}