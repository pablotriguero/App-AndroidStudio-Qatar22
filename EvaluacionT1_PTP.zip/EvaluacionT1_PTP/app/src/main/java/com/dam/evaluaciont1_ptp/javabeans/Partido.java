package com.dam.evaluaciont1_ptp.javabeans;

import android.os.Parcel;
import android.os.Parcelable;

public class Partido implements Parcelable {

    private String tv_Fase;
    private String tv_Fecha;
    private String tv_Equipo1;
    private int tv_Goles_Equipo1;
    private String tv_Equipo2;
    private int tv_Goles_Equipo2;

    public Partido(String tv_Fase, String tv_Fecha, String tv_Equipo1, int tv_Goles_Equipo1, String tv_Equipo2, int tv_Goles_Equipo2) {
        this.tv_Fase = tv_Fase;
        this.tv_Fecha = tv_Fecha;
        this.tv_Equipo1 = tv_Equipo1;
        this.tv_Goles_Equipo1 = tv_Goles_Equipo1;
        this.tv_Equipo2 = tv_Equipo2;
        this.tv_Goles_Equipo2 = tv_Goles_Equipo2;
    }

    protected Partido(Parcel in) {
        tv_Fase = in.readString();
        tv_Fecha = in.readString();
        tv_Equipo1 = in.readString();
        tv_Goles_Equipo1 = in.readInt();
        tv_Equipo2 = in.readString();
        tv_Goles_Equipo2 = in.readInt();
    }

    public static final Creator<Partido> CREATOR = new Creator<Partido>() {
        @Override
        public Partido createFromParcel(Parcel in) {
            return new Partido(in);
        }

        @Override
        public Partido[] newArray(int size) {
            return new Partido[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(tv_Fase);
        parcel.writeString(tv_Fecha);
        parcel.writeString(tv_Equipo1);
        parcel.writeInt(tv_Goles_Equipo1);
        parcel.writeString(tv_Equipo2);
        parcel.writeInt(tv_Goles_Equipo2);
    }

    public String getTv_Fase() {
        return tv_Fase;
    }

    public String getTv_Fecha() {
        return tv_Fecha;
    }

    public String getTv_Equipo1() {
        return tv_Equipo1;
    }

    public int getTv_Goles_Equipo1() {
        return tv_Goles_Equipo1;
    }

    public String getTv_Equipo2() {
        return tv_Equipo2;
    }

    public int getTv_Goles_Equipo2() {
        return tv_Goles_Equipo2;
    }

    public String toString() {
        return getTv_Fase() + " " + getTv_Fecha() + " | " + getTv_Equipo1() + " " + getTv_Goles_Equipo1() + " - " + getTv_Goles_Equipo2() + " " + getTv_Equipo2();
    }
}
