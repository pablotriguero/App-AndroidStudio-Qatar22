package com.dam.evaluaciont1_ptp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SeleccionActivity extends AppCompatActivity implements View.OnClickListener {

    Button Alemania;
    Button Arabia_Saudi;
    Button Argentina;
    Button Australia;
    Button Belgica;
    Button Brasil;
    Button Camerun;
    Button Canada;
    Button Corea_del_sur;
    Button Costa_rica;
    Button Croacia;
    Button Dinamarca;
    Button Ecuador;
    Button Espana;
    Button Estados_Unidos;
    Button Francia;
    Button Gales;
    Button Ghana;
    Button Holanda;
    Button Inglaterra;
    Button Iran;
    Button Japon;
    Button Marruecos;
    Button Mexico;
    Button Polonia;
    Button Portugal;
    Button Qatar;
    Button Senegal;
    Button Serbia;
    Button Suiza;
    Button Tunez;
    Button Uruguay;

    Button id_cancelar;
    Button id_aceptar;
    EditText et_PaisSeleccion;

    String Equipo;

    public static final int RESULTADO_EQUIPO1 = 101;
    public static final int RESULTADO_EQUIPO2 = 102;
    public static final String C_EQUIPO1 = "Equipo1";
    public static final String C_EQUIPO2 = "Equipo2";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seleccion);

        id_cancelar = findViewById(R.id.id_cancelar);
        id_aceptar = findViewById(R.id.id_aceptar);
        et_PaisSeleccion = findViewById(R.id.et_PaisSeleccion);

        Alemania = findViewById(R.id.Alemania);
        Arabia_Saudi = findViewById(R.id.Arabia_Saudi);
        Argentina = findViewById(R.id.Argentina);
        Australia = findViewById(R.id.Australia);
        Belgica = findViewById(R.id.Belgica);
        Brasil = findViewById(R.id.Brasil);
        Camerun = findViewById(R.id.Camerun);
        Canada = findViewById(R.id.Canada);
        Corea_del_sur = findViewById(R.id.Corea_del_sur);
        Costa_rica = findViewById(R.id.Costa_rica);
        Croacia = findViewById(R.id.Croacia);
        Dinamarca = findViewById(R.id.Dinamarca);
        Ecuador = findViewById(R.id.Ecuador);
        Espana = findViewById(R.id.Espana);
        Estados_Unidos = findViewById(R.id.Estados_Unidos);
        Francia = findViewById(R.id.Francia);
        Gales = findViewById(R.id.Gales);
        Ghana = findViewById(R.id.Ghana);
        Holanda = findViewById(R.id.Holanda);
        Inglaterra = findViewById(R.id.Inglaterra);
        Iran = findViewById(R.id.Iran);
        Japon = findViewById(R.id.Japon);
        Marruecos = findViewById(R.id.Marruecos);
        Mexico = findViewById(R.id.Mexico);
        Polonia = findViewById(R.id.Polonia);
        Portugal = findViewById(R.id.Portugal);
        Qatar = findViewById(R.id.Qatar);
        Senegal = findViewById(R.id.Senegal);
        Serbia = findViewById(R.id.Serbia);
        Suiza = findViewById(R.id.Suiza);
        Tunez = findViewById(R.id.Tunez);
        Uruguay = findViewById(R.id.Uruguay);

        et_PaisSeleccion.setEnabled(false);

        Alemania.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Alemania)));
            }
        });

        Arabia_Saudi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Arabia_Saudi)));
            }
        });

        Argentina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Argentina)));
            }
        });

        Australia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Australia)));
            }
        });

        Belgica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Belgica)));
            }
        });

        Brasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Brasil)));
            }
        });

        Camerun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Camerun)));
            }
        });

        Canada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Canada)));
            }
        });

        Corea_del_sur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Corea_del_sur)));
            }
        });

        Costa_rica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Costa_rica)));
            }
        });

        Croacia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Croacia)));
            }
        });

        Dinamarca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Dinamarca)));
            }
        });

        Ecuador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Ecuador)));
            }
        });

        Espana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Espana)));
            }
        });

        Estados_Unidos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Estados_Unidos)));
            }
        });

        Francia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Francia)));
            }
        });

        Gales.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Gales)));
            }
        });

        Ghana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Ghana)));
            }
        });

        Holanda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Holanda)));
            }
        });

        Inglaterra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Inglaterra)));
            }
        });

        Iran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Iran)));
            }
        });

        Japon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Japon)));
            }
        });

        Marruecos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Marruecos)));
            }
        });

        Mexico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Mexico)));
            }
        });

        Polonia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Polonia)));
            }
        });

        Portugal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Portugal)));
            }
        });

        Qatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Qatar)));
            }
        });

        Senegal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Senegal)));
            }
        });

        Serbia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Serbia)));
            }
        });

        Suiza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Suiza)));
            }
        });

        Tunez.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Tunez)));
            }
        });

        Uruguay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_PaisSeleccion.setText(String.format(getResources().getString(R.string.btn_Uruguay)));
            }
        });

        id_aceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (et_PaisSeleccion.getText().toString().isEmpty()){
                    Toast.makeText(SeleccionActivity.this, R.string.No_Pais, Toast.LENGTH_SHORT).show();
                } else {
                    Equipo =et_PaisSeleccion.getText().toString();

                    if(RegistrarResultadoActivity.EQUIPO1){
                        setResult(RESULTADO_EQUIPO1, new Intent().putExtra(C_EQUIPO1, Equipo));
                        RegistrarResultadoActivity.EQUIPO1 = false;
                    } else if(RegistrarResultadoActivity.EQUIPO2){
                        setResult(RESULTADO_EQUIPO2, new Intent().putExtra(C_EQUIPO2, Equipo));
                        RegistrarResultadoActivity.EQUIPO2 = false;
                    } else if(ConsultaActivity.EQUIPO) {
                        setResult(RESULT_OK, new Intent().putExtra(C_EQUIPO1, Equipo));
                        ConsultaActivity.EQUIPO = false;
                    }

                    finish();
                }

            }
        });

        id_cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_CANCELED, new Intent());
                finish();
            }
        });

    }


    @Override
    public void onClick(View view) {

    }
}