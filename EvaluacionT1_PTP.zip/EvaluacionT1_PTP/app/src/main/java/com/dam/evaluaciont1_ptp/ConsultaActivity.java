package com.dam.evaluaciont1_ptp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;

import com.dam.evaluaciont1_ptp.datos.Resultado;
import com.dam.evaluaciont1_ptp.fragmentos.ResultadoFragment;
import com.dam.evaluaciont1_ptp.javabeans.Partido;

import java.util.ArrayList;

public class ConsultaActivity extends AppCompatActivity {

    public static boolean EQUIPO = false;
    Button btn_seleccionar3;
    String Equipo;
    EditText et_IntroducirPais;
    Resultado resultadoClass = new Resultado();

    FrameLayout FragmentLayout1;
    FrameLayout FragmentLayout2;
    FrameLayout FragmentLayout3;
    FrameLayout FragmentLayout4;
    FrameLayout FragmentLayout5;
    FrameLayout FragmentLayout6;
    FrameLayout FragmentLayout7;

    ActivityResultLauncher<Intent> resultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    System.out.println("Resultado: " + result.getResultCode());
                    if (result.getResultCode() == -1) {
                        Equipo = result.getData().getStringExtra(SeleccionActivity.C_EQUIPO1);
                        et_IntroducirPais.setText(Equipo);
                        EQUIPO =false;
                        poblarResultados(Equipo);
                    }
                }
            }
    );

    private void poblarResultados(String Equipo) {
        ArrayList<Partido> partidos = resultadoClass.getListadoResultados();
        ArrayList<Partido> partidosFiltrados = new ArrayList<Partido>();
        for(int i = 0; i < partidos.size(); i++) {
            if(partidos.get(i).getTv_Equipo1().equals(Equipo) || partidos.get(i).getTv_Equipo2().equals(Equipo)) {
                partidosFiltrados.add(partidos.get(i));
            }
        }
        System.out.println(partidosFiltrados);

        for(int i = 0; i < partidosFiltrados.size(); i++) {
            //No he sabido continuar desde aquí.
            //ResultadoFragment resultadoFragment = new ResultadoFragment(partidosFiltrados.get(i));

        }

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta);
        /*Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable
                (new ColorDrawable(getResources().getColor(R.color.topBarRed)));

        getSupportActionBar().setTitle("Qatar22");*/

        btn_seleccionar3 = findViewById(R.id.btn_seleccionar3);
        et_IntroducirPais = findViewById(R.id.et_IntroducirPais);
        FragmentLayout1 = findViewById(R.id.FragmentLayout1);
        FragmentLayout2 = findViewById(R.id.FragmentLayout2);
        FragmentLayout3 = findViewById(R.id.FragmentLayout3);
        FragmentLayout4 = findViewById(R.id.FragmentLayout4);
        FragmentLayout5 = findViewById(R.id.FragmentLayout5);
        FragmentLayout6 = findViewById(R.id.FragmentLayout6);
        FragmentLayout7 = findViewById(R.id.FragmentLayout7);


        et_IntroducirPais.setEnabled(false);

        btn_seleccionar3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ConsultaActivity.this, SeleccionActivity.class);
                EQUIPO = true;
                resultLauncher.launch(i);
            }
        });
    }
}